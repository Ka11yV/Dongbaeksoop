package com.team.dto.user;

public class DashBoardStats {
}
